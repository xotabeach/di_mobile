data class FAQItem(
    val title: String,
    val content: String,
    var isExpanded: Boolean = false
)
