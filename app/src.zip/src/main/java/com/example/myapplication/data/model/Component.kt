package com.example.myapplication.data.model

data class Component(
    val name: String,
    val eNumber: String,
    val dangerLevel: Int,
    val diet: String
)