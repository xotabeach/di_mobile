package com.example.myapplication.data.model

data class Product(
    val name: String,
    val usefulness: Int,
    val diet: String
)