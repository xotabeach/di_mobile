package com.example.myapplication.doctor

data class DoctorItem(val question: String, val answer: String, var isExpanded: Boolean = false)